var { VerifyToken } = require("./JWT");

const data=[
    {
        id: 1,
        depositAmount: "1791",
        depositDate: "16/11/2020",
        postedId:'6666'
      },
      {
        id: 2,
        depositAmount: "17914",
        depositDate: "16/11/2020",
        postedId:'6666'
      },{
        id: 3,
        depositAmount: "4353",
        depositDate: "16/11/2020",
        postedId:'1212'
      },
];

module.exports.getselfDepositeAmount = async (req, res) => {

    try {
      res.status(200).json({
        message: "datas",
        data: data,
      });
    } catch (err) {
      res.status(404).json({ message: err.message });
    }
  };

  module.exports.postselfDepositeAmount=async(req,res)=>{

      const{depositAmount,depositDate} =req.body;
      let length=data.length;
      let datas={};
      datas.id=length;
    let dataed=VerifyToken(req);
      
      datas.depositAmount=depositAmount;
      datas.depositDate=depositDate;
      datas.postedId=dataed;
      data.push(datas);
      res.status(200).json({
          message:'deposite has been added'
      });
  }

  module.exports.patchselfDepositeAmount=async(req,res)=>{
    const{depositAmount,depositDate,id,postedId} =req.body;
    let length=data.length;
    let datas={};
  let i = data.findIndex((x) => x.id === id);
    datas.id=id;
    datas.depositAmount=depositAmount;
    datas.depositDate=depositDate;
    datas.postedId=postedId;
    data.splice(i,1,datas);
    res.status(200).json({
        message:'deposite has been updated'
    });
}

module.exports.deleteselfDepositeAmount=async(req,res)=>{
    let index=data.findIndex(x=>x.id===+req.params.id);
    data.splice(index,1);
    res.status(200).json({
        message:'requested data has been deleted'
    })
}