const data=[
    {
        id: 1,
        teamDepositAmount: "4353",
        selfDepositAmount: "4353",
        memberName: "Aript Srivastava : 9 %",
        memberId: "179144353",
      }
]


module.exports.GetIncomeDetail = async (req, res) => {
    try {
      res.status(200).json({
        message: "datas",
        data: data,
      });
    } catch (err) {
      res.status(404).json({ message: err.message });
    }
  };

  module.exports.teamDepositAmount=async(req,res)=>{
    const{ teamDepositAmount,memberName,memberId} =req.body;
    let length=data.length;
    let datas={};
    datas.id=length;
    datas. teamDepositAmount= teamDepositAmount;
    datas.memberName=memberName;
    datas.memberId=memberId;
    data.push(datas);
    res.status(200).json({
        message:'deposite has been added'
    });
  }

  module.exports.patchteamDepositeAmount=async(req,res)=>{
    const{teamDepositAmount,memberName,memberId,id} =req.body;
    let length=data.length;
    let datas={};
  let i = data.findIndex((x) => x.id === id);
    datas.id=id;
    datas.teamDepositAmount=teamDepositAmount;
    datas.memberName=memberName;
    datas.memberId=memberId;
    data.splice(i,1,datas);
    res.status(200).json({
        message:'deposite has been updated'
    });
}

  module.exports.deleteTeamDepositeAmount=async(req,res)=>{
    let index=data.findIndex(x=>x.id===+req.params.id);
    data.splice(index,1);
    res.status(200).json({
        message:'requested data has been deleted'
    })
}