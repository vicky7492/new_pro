const data=[
    {password:'212'}
]

module.exports.ChangePassord=async(req,res)=>{
    console.log(req.body)
    let i = data.findIndex((x) => x.password === req.body.OldPassword);
    console.log(req.body.OldPassword.length)
    console.log(i)
    if(i>-1 && req.body.OldPassword.length!==0){
        data[i].password=req.body.NewPassword;
        res.status(200).json({
            message:'password has been changed'
        })
    }else{
        res.status(400).json({
            mesage:'Password doesnt match'
        })
    }

}