var { creatTokens } = require("./JWT");

const data = [
  {
    memeberId: "2222",
    parentId: "none",
    membername: "membername",
    password: "password",
    teams: [],
    mobilenumber: "mobilenumber",
    email: "email",
    gender: "gender",
    joiningdate: "2022-04-12",
    district: "district",
    state: "state",
    pincode: "pincode",
    address: "address",
    nominename: "nominename",
    relation: "relation",
    bankname: "bankname",
    bankbranch: "bankbranch",
    accountnumber: "accountnumber",
    ifsccode: "ifsccode",
    pannumber: "pannumber",
    adharnumber: "adharnumber",
  },
  {
    memeberId: "22334",
    membername: "membername",
    password: "password",
    teams: [],
    mobilenumber: "mobilenumber",
    email: "email",
    gender: "gender",
    joiningdate: "2016-04-15",
    district: "district",
    state: "state",
    pincode: "pincode",
    address: "address",
    nominename: "nominename",
    relation: "relation",
    bankname: "bankname",
    bankbranch: "bankbranch",
    accountnumber: "accountnumber",
    ifsccode: "ifsccode",
    pannumber: "pannumber",
    adharnumber: "adharnumber",
    parentId: "2222",
  },
];

module.exports.getSingleUser = async (req, res) => {
  try {
    let index = data.findIndex((x) => x.memeberId === req.params.id);
    let datas = [data[index]];
    res.status(200).json({
      message: "datas",
      name: data[index].membername,
      joiningDate: data[index].joiningdate,
      mobilenumber: data[index].mobilenumber,

      data: datas,
    });
  } catch (err) {
    res.status(404).json({ message: err.message });
  }
};

// change Profile
module.exports.ChangePassword = async (req, res) => {
  let index = data.findIndex((x) => x.memeberId === req.body.memeberId);
  data.splice(index, 1, req.body);
  res.status(200).json({
    message: "profile has been updated",
  });
};

// register new user and get users
module.exports.getAll = async (req, res) => {
  try {
    res.status(200).json({
      message: "datas",
      data: data,
    });
  } catch (err) {
    res.status(504).json({ message: err.message });
  }
};
module.exports.AddNewTeamMember = async (req, res) => {
  let length = data.length;
  let memberId = length + 1200;
  req.body.memeberId = memberId.toString();
  req.body.id = length;
  // req.body.parentId='2222';
  req.body.teams = [];
  data.push(req.body);
  let index = data.findIndex((x) => x.memeberId === req.body.parentId);
  console.log(index);
  console.log(req.body.parentId);
console.log(data)
  if (data[index].teams.length !== 0) {
    data[index].teams = [...data[index].teams, req.body];
  } else {
    data[index].teams = [req.body];
  }

  console.log(data[index]);
  res.status(200).json({
    message: "user has been added",
    memeberId: memberId,
  });
};

module.exports.login = async (req, res) => {
  console.log(req.body);

  let dated = data.findIndex((x) => x.memeberId === req.body.userId);
  console.log(dated);
  if (dated > -1) {
    if (
      data[dated].memeberId === req.body.userId &&
      data[dated].password === req.body.NewPassword
    ) {
      const accesstoken = creatTokens(req.body.userId);
      console.log(accesstoken);
      res.cookie("access-token", accesstoken, {
        maxAge: 60 * 60 * 24 * 30 * 1000,
      });
      res.status(200).json({
        message: "login sucess full",
        token: accesstoken,
        userId: req.body.userId,
      });
    } else {
      res.status(400).json({
        message: "user id and password doesnt match",
      });
    }
  } else {
    res.status(400).json({
      message: "user id or password doesnt exist",
    });
  }
};

// register new user
module.exports.Register=async(req,res)=>{
    console.log(req.body);
    let length = data.length;
  let memberId = length + 1200;
  req.body.memeberId = memberId.toString();
  req.body.id = length;
  req.body.parentId='none';
  req.body.teams = [];
  data.push(req.body);
  res.status(200).json({
    message: "user has been added",
    memeberId: memberId,
  });
}